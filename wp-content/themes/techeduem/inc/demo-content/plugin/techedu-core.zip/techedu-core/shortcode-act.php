<?php
/**
* Define
*/
define( 'SPLG_URL', plugins_url() );
define( 'SPLG_DIR', dirname( __FILE__ ) );